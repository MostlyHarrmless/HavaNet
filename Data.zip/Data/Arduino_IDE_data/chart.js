const ctx = document.getElementById('chart').getContext('2d');

let chart = new Chart(ctx, {
  type: 'line',
  data: {
    datasets: [
      {
        label: 'دما (°C)',
        data: [],
        borderColor: '#f03e3e',
        backgroundColor: 'rgba(240, 62, 62, 0.1)',
        yAxisID: 'y',
      },
      {
        label: 'رطوبت (%)',
        data: [],
        borderColor: '#1c7ed6',
        backgroundColor: 'rgba(28, 126, 214, 0.1)',
        yAxisID: 'y1',
      },
      {
        label: 'فشار (hPa)',
        data: [],
        borderColor: '#2f9e44',
        backgroundColor: 'rgba(47, 158, 68, 0.1)',
        yAxisID: 'y2',
      },
      {
        label: 'گاز (ppm)',
        data: [],
        borderColor: '#fd7e14',
        backgroundColor: 'rgba(253, 126, 20, 0.1)',
        yAxisID: 'y3',
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      x: {
        type: 'linear',
        title: {
          display: true,
          text: 'زمان (ms)'
        }
      },
      y: {
        position: 'left',
        title: { display: true, text: 'دما' }
      },
      y1: {
        position: 'right',
        grid: { drawOnChartArea: false },
        title: { display: true, text: 'رطوبت' }
      },
      y2: {
        position: 'right',
        grid: { drawOnChartArea: false },
        title: { display: true, text: 'فشار' }
      },
      y3: {
        position: 'right',
        grid: { drawOnChartArea: false },
        title: { display: true, text: 'گاز' }
      }
    },
    plugins: {
      legend: { position: 'bottom' }
    }
  }
});

function updateChart() {
  fetch('/data')
    .then(res => res.json())
    .then(data => {
      const labels = data.map(e => parseInt(e.time) / 1000); // زمان به ثانیه
      chart.data.labels = labels;

      chart.data.datasets[0].data = data.map(e => ({ x: e.time / 1000, y: e.temp }));
      chart.data.datasets[1].data = data.map(e => ({ x: e.time / 1000, y: e.hum }));
      chart.data.datasets[2].data = data.map(e => ({ x: e.time / 1000, y: e.pres }));
      chart.data.datasets[3].data = data.map(e => ({ x: e.time / 1000, y: e.gas }));

      chart.update();

      // مقدارهای آخر را در صفحه هم نمایش بده
      let last = data[data.length - 1];
      if (last) {
        document.getElementById("temp").textContent = last.temp.toFixed(1);
        document.getElementById("hum").textContent = last.hum.toFixed(1);
        document.getElementById("pres").textContent = last.pres.toFixed(1);
        document.getElementById("gas").textContent = last.gas.toFixed(1);
      }
    });
}

updateChart();
setInterval(updateChart, 5000); // هر ۵ ثانیه

// حالت تاریک/روشن
const themeSwitch = document.getElementById('themeSwitch');
themeSwitch.addEventListener('change', () => {
  document.body.classList.toggle('dark', themeSwitch.checked);
});
